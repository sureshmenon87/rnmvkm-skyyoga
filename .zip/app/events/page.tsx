export default function EventsPage() {
  return (
    <main style={{ padding: "40px" }}>
      <h1>Events</h1>
      <p>Upcoming SKY Yoga programs will be listed here.</p>
    </main>
  );
}
