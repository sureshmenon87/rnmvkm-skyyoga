import TrainingCardTable from "@/components/TrainingCardTable";
import { tableLeft, tableRight } from "@/data/trainingData";

export default function TrainingsPage() {
  return (
    <main className="bg-[#fffdf2]">
      {/* Header */}
      {/* (Paste ribbon + Maharishi section here) */}

      {/* Tables */}
      <section className="px-4 md:px-10 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-6xl mx-auto">
          <TrainingCardTable
            title="உடல் & மூச்சுப் பயிற்சிகள்"
            rows={tableLeft}
          />
          <TrainingCardTable
            title="தியான & வாழ்க்கை பயிற்சிகள்"
            rows={tableRight}
          />
        </div>
      </section>
    </main>
  );
}
